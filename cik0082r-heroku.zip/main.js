/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
const http = require('http');
// listen on port
const port = 3500;

var server = http.createServer(function (req, res) {
    var page_text = '系統維護中,暫停使用!';
    var page_time = '2022/05/23(一) 23:30 ~ 2022/05/24(二) 06:30';
    var page_info = '<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8"></head><body><h1><font color="#FF0000">'+page_text+'</font><br/>'+page_time+'</h1></body></html>';
     if (req.url == '/cik0082r') {
        res.writeHead(200, {'Content-Type': 'text/html'});
        res.write(page_info);
        res.end();    
    } else
        res.end(page_info);

});
server.listen(port);

